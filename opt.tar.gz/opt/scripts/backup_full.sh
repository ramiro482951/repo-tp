#!/bin/bash


#funcion de ayuda
show_help() {
    echo "uso: $0 [-h] [-o origen] [-d destino]"
    echo ""
    echo "opciones:"
    echo "  -h             muestra esta ayuda."
    echo "  -o origen      directorio a respaldar (obligatorio)."
    echo "  -d destino     directorio de destino para almacenar el backup (obligatorio)."
 }

#verificacion de argumentos
while getopts ":ho:d:" opt; do
    case ${opt} in
        h) #mostrar ayuda
           show_help
           exit 0
           ;;
        o) #origen del backup
           ORIGEN=$OPTARG
           ;;
        d) #destino del backup
           DESTINO=$OPTARG
           ;;
        /?) #caso de opcion invalida
            echo "opcion invalida: -$OPTARG"
            show_help
            exit 1
            ;;
    esac
done

#verificar que los directorios de origen y destino existan
if [ ! -d "$ORIGEN" ]; then
    echo  "el directorio de origen '$ORIGEN' no existe."
    exit 1
fi

if [ ! -d "$DESTINO" ]; then
    echo "el directorio de destino '$DESTINO' no esxiste."
    exit 1
fi

#fecha actual en formato YYYYMMDD
FECHA=$(date +%Y%md)

#crear el nombre del archivo de backup
ARCHIVO_BACKUP=$(basename "$ORIGEN")_bkp_$FECHA.tar.gz

#ruta completa del archivo de backup
RUTA_DESTINO="$DESTINO/$ARCHIVO_BACKUP"

#crear el backup usando tar
echo "iniciando el backup de $ORIGEN en $RUTA_DESTINO..."
tar -czf "$RUTA_DESTINO" "$ORIGEN"

#verificar que el comando tar se ejecuto correctamente
if [ $? -eq 0 ]; then
    echo "backup completado exitosamente: $RUTA_DESTINO"
else
    echo "hubo un error al realizar el backup."
    exit 1
fi
